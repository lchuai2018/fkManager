'use strict'
module.exports = {
  NODE_ENV: '"test"',
  BASE_API: '"http://test-risk.mossisk.com/"',
}
